<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>403 - Acceso Denegado</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="d-flex align-items-center justify-content-center" style="min-height:100vh;background:#f8fafc">
<div class="text-center">
    <h1 class="display-1 text-danger">403</h1>
    <h3>Acceso Denegado</h3>
    <p class="text-muted">No tienes permisos para acceder a esta página.</p>
    <a href="/" class="btn btn-primary">Volver al inicio</a>
</div>
</body>
</html>
